#!/bin/bash
### BEGIN INIT INFO
# Provides:          web2ip
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       capture cidr from acl
# Authors:           Maravento.com and Novatoz.com
# Permisos:          root y chmod +x
# used:              host -t a or dig +short -f
### END INIT INFO
route=/etc/acl
tmp=/tmp

cd /tmp
function whitelistwebupdate(){
	wget -c --retry-connrefused -t 0 https://www.googledrive.com/host/0B0IOC2-GhY8PczREUGI2TEFqa2c -O whitedomains.txt
	wget -c --retry-connrefused -t 0 https://www.googledrive.com/host/0B0IOC2-GhY8PeHZvLUU5MkVHS00 -O whitedomains.md5
}
whitelistwebupdate

a=$(md5sum whitedomains.txt | awk '{print $1}')
b=$(cat whitedomains.md5 | awk '{print $1}')

if [ "$a" = "$b" ]
then 
	echo " la suma coincide"
	cat whitedomains.txt >> $route/whitedomains.txt
	rm -f whitedomains*
	cat $route/whitedomains.txt | sed '/^$/d; / *#/d' | sed 's:^\.::' | sort -u  > $tmp/cleardomains.txt
	for ip in `cat $tmp/cleardomains.txt`; do
	for sub in "" "www." "ftp."; do
		host -t a "${sub}${ip}";
	done
    done | awk 'BEGIN { FS = " " } ; { print $4 }' | egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n | sort -u >> $route/whiteips.txt
   sort -o $route/whiteips.txt -u $route/whiteips.txt -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n $route/whiteips.txt
echo done
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "<--| Update Whiteips: ejecucion $date |-->" >> /var/log/alert.log
	echo " OK"
else
	echo " la suma no coincide"
	echo " Verifique su conexion de internet y reinicie el script"
	rm -f whitedomains*
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "<--| Update Whiteips: abortada $date |-->" >> /var/log/alert.log
	exit
fi
