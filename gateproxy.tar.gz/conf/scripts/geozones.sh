#!/bin/bash
### BEGIN INIT INFO
# Provides:          geozones
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
### END INIT INFO
if [ ! -d /etc/zones ]; then mkdir -p /etc/zones; fi
wget -c --retry-connrefused -t 0 http://www.ipdeny.com/ipblocks/data/countries/all-zones.tar.gz && tar -C /etc/zones -zxvf all-zones.tar.gz && rm -R all-zones.tar.gz
# reporte log
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "<--| Geozones-ipset: ejecucion $date |-->" >> /var/log/alert.log
