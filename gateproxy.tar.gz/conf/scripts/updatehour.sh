#!/bin/bash
### BEGIN INIT INFO
# Provides:          Correccion Hora
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
### END INIT INFO
# by babysysadmin.wordpress.com
ntpd -gq
hwclock -w
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "<--| Update Hour: ejecucion $date |-->" >> /var/log/alert.log
