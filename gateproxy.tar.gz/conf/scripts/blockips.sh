#!/bin/bash
### BEGIN INIT INFO
# Provides:          blockips
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
# Authors:           Maravento.com and Novatoz.com
# Special thanks:    zeustracker.abuse.ch
### END INIT INFO

cd /tmp
echo "Download and capture Zeus badips..."
wget -c --retry-connrefused -t 0 'https://zeustracker.abuse.ch/blocklist.php?download=badips' -O ipszeus.txt >/dev/null 2>&1
cat ipszeus.txt | sed '/#.*/d' | sed '/^$/d' | sort -u > 1ips.txt

echo "Download and capture Ransomware badips..."
wget -c --retry-connrefused -t 0 'https://ransomwaretracker.abuse.ch/downloads/RW_IPBL.txt' -O ipsransomware.txt >/dev/null 2>&1
egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" ipsransomware.txt | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n | sed '/#.*/d' | sed '/^$/d' | sort -u > 2ips.txt

echo "Download and capture Tor exit addresses..."
wget -c --retry-connrefused -t 0 'https://check.torproject.org/exit-addresses' -O ipstor.txt >/dev/null 2>&1
egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" ipstor.txt | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n | sed '/#.*/d' | sed '/^$/d' | sort -u > 3ips.txt >/dev/null 2>&1

echo "Capture ips from syslogemu.log..."
grep -Eo 'SRC=[0-9.]+' /var/log/ulog/syslogemu.log | sed 's:SRC=::' | sort -u > ipsyslogemu.txt

echo "Joint and debugged blackips (exclude dmz)..."
cat 1ips.txt 2ips.txt 3ips.txt ipsyslogemu.txt /etc/acl/blackips.txt | sed '/#.*/d' | sed '/^$/d' | sort -u > ips.txt
sed '/#.*/d' /etc/acl/whiteips.txt | sed '/^$/d' | sort -u > ipsdmz.txt
python /etc/init.d/filter.py ipsdmz.txt | grep -Fxvf - ips.txt > /etc/acl/blackips.txt
sort -o /etc/acl/blackips.txt -u /etc/acl/blackips.txt -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n /etc/acl/blackips.txt

#echo "empty log..."
#cat /dev/null > /var/log/ulog/syslogemu.log
#rm -rf /var/log/ulog/syslogemu.log.*
#rm -rf /var/log/ulog/*.gz

echo "log registry and end script"
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "<--| Blockips for ipset: ejecucion $date |-->" >> /var/log/alert.log
