#!/bin/bash
### BEGIN INIT INFO
# Provides:          blackips for ipset
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       capture cidr from acl
# Authors:           Maravento.com and Novatoz.com
# Permisos:          root y chmod +x
# used:              host -t a or dig +short -f
### END INIT INFO

# CREATE /etc/zones and /etc/acl
if [ ! -d /etc/zones ]; then mkdir -p /etc/zones; fi
if [ ! -d /etc/acl ]; then mkdir -p /etc/acl; fi

# GIT CLONE BLACKIPS
echo "Descargando proyecto Blackips..."
git clone https://github.com/maravento/blackips

# DOWNLOAD GEOZONES
echo "Descargando GeoIps..."
wget -c --retry-connrefused -t 0 http://www.ipdeny.com/ipblocks/data/countries/all-zones.tar.gz && tar -C /etc/zones -zxvf all-zones.tar.gz >/dev/null 2>&1 && rm -f all-zones.tar.gz

# CAPTURE WHITEIPS
echo "Iniciando la captura de Whiteips. Espere..."
cat blackips/whiteurls.txt | sed '/^$/d; / *#/d' | sed 's:^\.::' | sort -u  > blackips/ipsurls.txt
	for ip in `cat blackips/ipsurls.txt`; do
	for sub in "" "www." "ftp."; do
		host -t a "${sub}${ip}";
	done
  done | awk 'BEGIN { FS = " " } ; { print $4 }' | egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n | sort -u >> blackips/whiteips.txt
  sort -o blackips/whiteips.txt -u blackips/whiteips.txt -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n blackips/whiteips.txt

# DOWNLOAD EXTRA BLACKIPS
echo "Download and capture Zeus badips..."
wget -c --retry-connrefused -t 0 'https://zeustracker.abuse.ch/blocklist.php?download=badips' -O blackips/ipszeus.txt >/dev/null 2>&1
sed '/#.*/d' blackips/ipszeus.txt | sed '/^$/d' | sort -u > blackips/tmp1.txt

echo "Download and capture Ransomware badips..."
wget -c --retry-connrefused -t 0 'https://ransomwaretracker.abuse.ch/downloads/RW_IPBL.txt' -O blackips/ipsransomware.txt >/dev/null 2>&1
egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" blackips/ipsransomware.txt | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n | sed '/#.*/d' | sed '/^$/d' | sort -u > blackips/tmp2.txt

echo "Download and capture Tor exit addresses..."
wget -c --retry-connrefused -t 0 'https://check.torproject.org/exit-addresses' -O blackips/ipstor.txt >/dev/null 2>&1
egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" blackips/ipstor.txt | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n | sed '/#.*/d' | sed '/^$/d' | sort -u > blackips/tmp3.txt

# CAPTURE IPS FROM ULOG
echo "Capture ips from syslogemu.log..."
grep -Eo 'SRC=[0-9.]+' /var/log/ulog/syslogemu.log | sed 's:SRC=::' | sort -u > blackips/syslogemu.txt
cat /dev/null > /var/log/ulog/syslogemu.log

# JOINT AND DEBUGGED
echo "Joint whiteips..."
cat blackips/whiteips.txt /etc/acl/whiteips.txt | sed '/#.*/d' | sed '/^$/d' | sort -u > blackips/whitefinal.txt
sort -o blackips/whiteips.txt -u blackips/whiteips.txt -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n blackips/whiteips.txt
echo "Joint and debugged blackips (exclude whiteips)..."
cat blackips/tmp1.txt blackips/tmp2.txt blackips/tmp3.txt blackips/syslogemu.txt blackips/blackips.txt /etc/acl/blackips.txt | sed '/#.*/d' | sed '/^$/d' | sort -u > blackips/blackfinal.txt
sort -o blackips/blackfinal.txt -u blackips/blackfinal.txt -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n blackips/blackfinal.txt
chmod +x blackips/filter.py
python blackips/filter.py blackips/whitefinal.txt | grep -Fxvf - blackips/blackfinal.txt > /etc/acl/blackips.txt
sort -o /etc/acl/blackips.txt -u /etc/acl/blackips.txt -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n /etc/acl/blackips.txt
cp -f blackips/whitefinal.txt /etc/acl/whiteips.txt

# LOG
rm -rf blackips
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "Blackips for Ipset: ejecucion $date" >> /var/log/syslog.log
echo Done
