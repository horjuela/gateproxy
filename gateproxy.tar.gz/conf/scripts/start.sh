#!/bin/bash
### BEGIN INIT INFO
# Provides:          Start
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
# By Maravento.com and Novatoz.com
### END INIT INFO

# Services
/etc/init.d/leases.sh
/etc/init.d/iptables.sh
service squid start
service apache2 start
service ntopng start
service redis-server start
/etc/init.d/dnsmasq start
echo OK
date=`date +%d/%m/%Y" "%H:%M:%S`
echo "<--| Se iniciaron todos los servicios $date |-->" >> /var/log/alert.log
