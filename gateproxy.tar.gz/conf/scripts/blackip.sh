#!/bin/bash
### BEGIN INIT INFO
# Provides:          Blackips for Ipset
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       capture cidr from acl
# Authors:           Maravento.com and Novatoz.com
# Permisos:          root y chmod +x
# used:              host -t a or dig +short -f
### END INIT INFO

# GIT CLONE BLACKIP
echo "Descargando Proyecto Blackip..."
git clone https://github.com/maravento/blackip

# CHECKSUM AND COPY /etc/acl
a=$(md5sum blackip/blackip.tar.gz | awk '{print $1}')
b=$(cat blackip/blackip.md5 | awk '{print $1}')
c=$(md5sum blackip/whiteip.txt | awk '{print $1}')
d=$(cat blackip/whiteip.md5 | awk '{print $1}')

if [ "$a" = "$b" ] && [ "$c" = "$d" ]
then
	tar -C blackip -xvzf blackip/blackip.tar.gz >/dev/null 2>&1
	# CREATE /etc/zones and /etc/acl
	if [ ! -d /etc/zones ]; then mkdir -p /etc/zones; fi
	if [ ! -d /etc/acl ]; then mkdir -p /etc/acl; fi
	# DOWNLOAD GEOZONES
	echo "Descargando GeoIps for Ipset..."
	wget -c --retry-connrefused -t 0 http://www.ipdeny.com/ipblocks/data/countries/all-zones.tar.gz && tar -C /etc/zones -zxvf all-zones.tar.gz >/dev/null 2>&1 && rm -f all-zones.tar.gz
	# DOWNLOAD EXTRA blackip
	echo "Download and capture Zeus badips..."
	wget -c --retry-connrefused -t 0 'https://zeustracker.abuse.ch/blocklist.php?download=badips' -O blackip/ipszeus.txt >/dev/null 2>&1
	sed '/^$/d; / *#/d' blackip/ipszeus.txt | sort -u >> blackip/blackip.txt && rm -f blackip/ipszeus.txt
	echo "Download and capture Ransomware badips..."
	wget -c --retry-connrefused -t 0 'https://ransomwaretracker.abuse.ch/downloads/RW_IPBL.txt' -O blackip/ipsransomware.txt >/dev/null 2>&1
	egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" blackip/ipsransomware.txt | sed '/^$/d; / *#/d' | sort -u >> blackip/blackip.txt && rm -f blackip/ipsransomware.txt
	echo "Download and capture Tor exit addresses..."
	wget -c --retry-connrefused -t 0 'https://check.torproject.org/exit-addresses' -O blackip/ipstor.txt >/dev/null 2>&1
	egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" blackip/ipstor.txt | sed '/^$/d; / *#/d' | sort -u >> blackip/blackip.txt && rm -f blackip/ipstor.txt
	echo "Download and capture BL Myip..."
	wget -c --retry-connrefused -t 0 'https://myip.ms/files/blacklist/general/full_blacklist_database.zip'
	unzip full_blacklist_database.zip -d blackip
	sed -e 's/#.*$//' -e '/^$/d' blackip/full_blacklist_database.txt | egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" >> blackip/blackip.txt && rm -f blackip/full_blacklist_database*
	# CAPTURE IPS FROM ULOG
	echo "Capture ips from syslogemu.log..."
	grep -Eo 'SRC=[0-9.]+' /var/log/ulog/syslogemu.log | sed 's:SRC=::' | sed '/^$/d; / *#/d' | sort -u >> blackip/blackip.txt && cat /dev/null > /var/log/ulog/syslogemu.log
	echo 
	sed '/^$/d; / *#/d' blackip/whiteip.txt /etc/acl/whiteip.txt | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n -u > blackip/whitefinal.txt
	sed '/^$/d; / *#/d' blackip/blackip.txt /etc/acl/blackip.txt | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n -u > blackip/blackfinal.txt
	# DEBUGGED
	echo "Debugged blackip (exclude whiteip)..."
	chmod +x blackip/filter.py
	python blackip/filter.py blackip/whitefinal.txt | grep -Fxvf - blackip/blackfinal.txt > /etc/acl/blackip.txt
	sort -o /etc/acl/blackip.txt -u /etc/acl/blackip.txt -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n /etc/acl/blackip.txt
    cp -f blackip/whitefinal.txt /etc/acl/whiteip.txt
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "Blackip for Ipset: ejecucion $date" >> /var/log/syslog.log
  else
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "Blackip for Ipset: abortada $date.. Verifique su conexion de internet" >> /var/log/syslog.log
fi

rm -rf blackip
echo Done
