#!/bin/bash
### BEGIN INIT INFO
# Provides:          Blackips for Ipset
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       capture cidr from acl
# Authors:           Maravento.com and Novatoz.com
# Permisos:          root y chmod +x
# used:              host -t a or dig +short -f
### END INIT INFO

# CREATE /etc/zones and /etc/acl
if [ ! -d /etc/zones ]; then mkdir -p /etc/zones; fi
if [ ! -d /etc/acl ]; then mkdir -p /etc/acl; fi

# DOWNLOAD GEOZONES
echo "Descargando GeoIps for Ipset..."
wget -c --retry-connrefused -t 0 http://www.ipdeny.com/ipblocks/data/countries/all-zones.tar.gz && tar -C /etc/zones -zxvf all-zones.tar.gz >/dev/null 2>&1 && rm -f all-zones.tar.gz

# GIT CLONE BLACKIP
echo "Descargando Proyecto Blackip..."
git clone https://github.com/maravento/blackip >/dev/null 2>&1

# CHECKSUM AND COPY /etc/acl
a=$(md5sum blackip/blackip.tar.gz | awk '{print $1}')
b=$(cat blackip/blackip.md5 | awk '{print $1}')

if [ "$a" = "$b" ]
then 
	tar -C blackip -xvzf blackip/blackip.tar.gz >/dev/null 2>&1
	cp -f blackip/blackip.txt /etc/acl >/dev/null 2>&1
  	rm -rf blackip
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "Blackip for Ipset: ejecucion $date" >> /var/log/syslog.log
else
	rm -rf blackip
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "Blackip for Ipset: abortada $date Verifique su conexion de internet" >> /var/log/syslog.log
	exit
fi
