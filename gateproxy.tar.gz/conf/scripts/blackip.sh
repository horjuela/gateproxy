#!/bin/bash
### BEGIN INIT INFO
# Provides:          Blackips for Ipset
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       capture cidr from acl
# Authors:           Maravento.com and Novatoz.com
# Permisos:          root y chmod +x
# used:              host -t a or dig +short -f
### END INIT INFO

# GIT CLONE BLACKIP
echo "Descargando Proyecto Blackip..."
git clone https://github.com/maravento/blackip

# CHECKSUM AND COPY /etc/acl
a=$(md5sum blackip/blackip.tar.gz | awk '{print $1}')
b=$(cat blackip/blackip.md5 | awk '{print $1}')
c=$(md5sum blackip/whiteip.txt | awk '{print $1}')
d=$(cat blackip/whiteip.md5 | awk '{print $1}')

if [ "$a" = "$b" ] && [ "$c" = "$d" ]
then
	tar -C blackip -xvzf blackip/blackip.tar.gz >/dev/null 2>&1
	# CREATE /etc/zones and /etc/acl
	if [ ! -d /etc/zones ]; then mkdir -p /etc/zones; fi
	if [ ! -d /etc/acl ]; then mkdir -p /etc/acl; fi

	# DOWNLOAD GEOZONES
	echo "Download GeoIps for Ipset..."
	wget -c --retry-connrefused -t 0 http://www.ipdeny.com/ipblocks/data/countries/all-zones.tar.gz && tar -C /etc/zones -zxvf all-zones.tar.gz >/dev/null 2>&1 && rm -f all-zones.tar.gz

	# DOWNLOAD AND CAPTURE WHITEIPS
	echo "Whiteips Update..."
	wget -c --retry-connrefused -t 0 https://www.googledrive.com/host/0B0IOC2-GhY8PczREUGI2TEFqa2c -O blackip/whiteurls.txt
	cat blackip/whiteurls.txt | sed '/^$/d; / *#/d' | sed 's:^\.::' | sort -u  > blackip/cleanurls.txt
		for ip in `cat blackips/cleanurls.txt`; do
			for sub in "" "www." "ftp."; do
				host -t a "${sub}${ip}";
			done
  	done | awk 'BEGIN { FS = " " } ; { print $4 }' | egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" | sort -u >> blackips/whiteips.txt && rm -f blackip/*urls.txt

	# DOWNLOAD EXTRA BLACKIPS
	echo "Download and capture Zeus badips..."
	wget -c --retry-connrefused -t 0 'https://zeustracker.abuse.ch/blocklist.php?download=badips' -O blackip/ipszeus.txt >/dev/null 2>&1
	sed '/^$/d; / *#/d' blackip/ipszeus.txt | sort -u >> blackip/blackip.txt && rm -f blackip/ipszeus.txt
	echo "Download and capture Ransomware badips..."
	wget -c --retry-connrefused -t 0 'https://ransomwaretracker.abuse.ch/downloads/RW_IPBL.txt' -O blackip/ipsransomware.txt >/dev/null 2>&1
	egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" blackip/ipsransomware.txt | sed '/^$/d; / *#/d' | sort -u >> blackip/blackip.txt && rm -f blackip/ipsransomware.txt
	echo "Download and capture Tor exit addresses..."
	wget -c --retry-connrefused -t 0 'https://check.torproject.org/exit-addresses' -O blackip/ipstor.txt >/dev/null 2>&1
	egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" blackip/ipstor.txt | sed '/^$/d; / *#/d' | sort -u >> blackip/blackip.txt && rm -f blackip/ipstor.txt
	echo "Download and capture BL Myip..."
	wget -c --retry-connrefused -t 0 'https://myip.ms/files/blacklist/general/full_blacklist_database.zip'
	unzip full_blacklist_database.zip -d blackip
	sed -e 's/#.*$//' -e '/^$/d' blackip/full_blacklist_database.txt | egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" >> blackip/blackip.txt && rm -f blackip/full_blacklist_database*
	
	# CAPTURE IPS FROM ULOG
	echo "Capture IPs from syslogemu.log..."
	grep -Eo 'SRC=[0-9.]+' /var/log/ulog/syslogemu.log | sed 's:SRC=::' | sed '/^$/d; / *#/d' | sort -u >> blackip/blackip.txt
	cat /dev/null > /var/log/ulog/syslogemu.log

	# CAPTURE IPS FROM SQUID ACCESS.LOG
	echo "Capture IPs from Squid access.log..."
	cat /var/log/squid/access.log | grep -i 'TCP_DENIED/403' | egrep -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" | sed '/^$/d; / *#/d' | sort -u >> blackip/blackip.txt
	cat /dev/null > /var/log/squid/access.log

	# JOINT AND DEBUGGED
	echo "Joint whiteip..."
	cat blackip/whiteip.txt /etc/acl/whiteip.txt | sed '/^$/d; / *#/d' | sort -u | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n > blackip/whitefinal.txt
	echo "Joint blackip..."
	cat blackip/blackip.txt /etc/acl/blackip.txt | sed '/^$/d; / *#/d' | sort -u | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n > blackip/blackfinal.txt
	echo "Debugged blackip (exclude whiteip)..."
	chmod +x blackip/filter.py
	python blackip/filter.py blackip/whitefinal.txt | grep -Fxvf - blackip/blackfinal.txt | sort -u | sort -t . -k 1,1n -k 2,2n -k 3,3n -k 4,4n > /etc/acl/blackip.txt && rm -f blackip/blackfinal.txt && mv -f blackip/whitefinal.txt /etc/acl/whiteip.txt

	# LOG
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "Blackip for Ipset: ejecucion $date" >> /var/log/syslog.log
  else
	date=`date +%d/%m/%Y" "%H:%M:%S`
	echo "Blackip for Ipset: abortada $date.. Verifique su conexion de internet" >> /var/log/syslog.log
fi

rm -rf blackip
echo "Done"
