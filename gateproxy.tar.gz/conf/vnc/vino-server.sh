#!/bin/bash
### BEGIN INIT INFO
# Provides:          vino-server
# Required-Start:    $local_fs
# Required-Stop:     $local_fs
# Should-Start:
# Should-Stop:
# X-Start-Before:
# X-Stop-After:
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: vino-server
# Link # Link: https://gist.github.com/torson/10b624108258631beb42
### END INIT INFO

PIDFILE="/tmp/vino-server.pid"
NAME="vino-server"
GREPFILTER="/usr/lib/vino/vino-server"

service_kill() {

       ### kill -9
       PIDS="`ps aux |grep -v grep |grep -P "${GREPFILTER}" |awk '{print $2}' | tr '\n' ' ' `"
       if [ -n "$PIDS" ]; then
           echo "sleep 5"
           sleep 5
           PIDS="`ps aux |grep -v grep |grep -P "${GREPFILTER}" |awk '{print $2}' | tr '\n' ' ' `"
           if [ -n "$PIDS" ]; then
               echo "kill -9 ${PIDS}"
               kill -9 ${PIDS}
           fi
       fi
       if [ -f ${PIDFILE} ]; then
           echo "rm ${PIDFILE}"
           rm ${PIDFILE}
       fi
}

service_status() {
       PID="`cat ${PIDFILE}`"
       if [ -n "$PID" ]; then
           echo "${PIDFILE} : ${PID}"
       else
           echo "file doesnt' exist : ${PIDFILE}"
       fi
       PIDS="`ps aux |grep -v grep |grep -P "${GREPFILTER}" |awk '{print $2}' | tr '\n' ' ' `"
       if [ -n "$PIDS" ]; then
           echo "PROCESSES:"
           echo "$PIDS"
       fi
}

service_start() {
       PIDS="`ps aux |grep -v grep |grep -P "${GREPFILTER}" |awk '{print $2}' | tr '\n' ' ' `"
       if [ -n "$PIDS" ]; then
            echo "process is present : ${PIDS}"
            echo $PIDS > ${PIDFILE}
            chmod 644 ${PIDFILE}
            exit 0
       else

            gconftool-2 -s -t bool /desktop/gnome/remote_access/enabled true
            gconftool-2 --type bool --set /desktop/gnome/remote_access/prompt_enabled 0
            export DISPLAY=:0.0
            /usr/lib/vino/vino-server --sm-disable &

            sleep 2

            PIDS="`ps aux |grep -v grep |grep -P "${GREPFILTER}" |awk '{print $2}' | tr '\n' ' ' `"
            if [ -n "$PIDS" ]; then
                 echo "$PIDS"
                 echo $PIDS > ${PIDFILE}
                 chmod 644 ${PIDFILE}
            fi
       fi
}
service_stop() {
       PIDS="`ps aux |grep -v grep |grep -P "${GREPFILTER}" |awk '{print $2}' | tr '\n' ' ' `"
       if [ -n "$PIDS" ]; then
           echo "kill ${PIDS}"
           kill ${PIDS}
       fi
       if [ -f ${PIDFILE} ]; then
           echo "rm ${PIDFILE}"
           rm ${PIDFILE}
       fi
}

case $1 in
   start)
     service_start;;
   stop)
     service_stop;
     service_kill;;
   kill)
     service_kill;;
   restart)
     service_stop;
     service_start;;
   status)
     service_status;;
   *)
     echo "usage: $0 {start|stop|kill|restart|status}" ;
     echo "example: $0 start" ;
esac
exit 0
